import torch
import SNN_pkg as pkg

data=pkg.tools.SimpleDeap("/home/featurize/work/Project/DEAP")
train_data,test_data=data.split(0.01)
print("Length of test data: {}".format(len(test_data)))
train_ds=torch.utils.data.DataLoader(train_data, batch_size=5)
test_ds=torch.utils.data.DataLoader(test_data, batch_size=len(test_data))
EEG_model=pkg.StdpModel.EEG_SequentialCompressionUnit()
STDP_exe=pkg.StdpModel.STDPExe(EEG_model, "model", train_ds, test_ds)
Reg_model=pkg.Regression.EEG_Reg()
Reg_exe=pkg.Regression.RegExe(Reg_model, STDP_exe, "model", train_ds, test_ds)
Reg_exe.train(1)

